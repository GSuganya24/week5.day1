package week5.day1;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class UpdateIncident extends BaseClass_Incident {
	@Test(enabled = true)
	public  void updateIncident() throws InterruptedException {
	//public static void main(String[] args) throws InterruptedException {
		//Enter into the search field
		WebElement search1 = driver.findElement(By.xpath("//input[@class='form-control']"));
		search1.sendKeys(inciNum);
		search1.sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//table[@id='incident_table']/tbody/tr/td[3]/a")).click();
		Select dd1 = new Select(driver.findElement(By.id("incident.urgency")));
		dd1.selectByValue("1");
		//Select State
		Select dd2 = new Select(driver.findElement(By.id("incident.state")));
		dd2.selectByValue("2");
		driver.findElement(By.id("sysverb_update_bottom")).click();
		Thread.sleep(2000);
		WebElement search2 = driver.findElement(By.xpath("//input[@class='form-control']"));
		search2.sendKeys(inciNum);
		search2.sendKeys(Keys.ENTER);
		Thread.sleep(500);
		driver.findElement(By.xpath("//table[@id='incident_table']/tbody/tr/td[3]/a")).click();
		//Get the values of the fields 'urgency&state' and whether updated
		WebElement urgency = driver.findElement(By.xpath("//select[@id='incident.urgency']//option[@selected='SELECTED']"));
		String urg = urgency.getText();
		System.out.println(urg);
		WebElement state = driver.findElement(By.xpath("//select[@id='incident.state']//option[2][@selected='SELECTED']"));
		String state1 = state.getText();
		System.out.println(state1);
		if(urg.contains("High") && state1.contains("Progress")) {
			System.out.println("The incident is updated");
		}else {
			System.out.println("The incident is not updated");
		}

		
	}
}
